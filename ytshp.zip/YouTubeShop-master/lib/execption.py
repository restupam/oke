class LoginFailed(RuntimeError):
	pass